﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopWindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string command;
        


        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.Text == "Orders" && comboBox3.Text == "Post")
            {
                command = tb_View.Text = "{\r\n  \"userId\": 0,\r\n  \"items\": [\r\n    {\r\n      \"productId\": 0,\r\n      \"count\": 0,\r\n      \"discount\": 0\r\n    }\r\n  ]\r\n}";
            }
            if (comboBox2.Text == "Orders" && comboBox3.Text == "Post")
            {
                command = tb_View.Text = "{\r\n  \"userId\": 0,\r\n  \"items\": [\r\n    {\r\n      \"productId\": 0,\r\n      \"count\": 0,\r\n      \"discount\": 0\r\n    }\r\n  ]\r\n}";
            }
            if (comboBox2.Text == "Orders" && comboBox3.Text == "Post")
            {
                command = tb_View.Text = "{\r\n  \"userId\": 0,\r\n  \"items\": [\r\n    {\r\n      \"productId\": 0,\r\n      \"count\": 0,\r\n      \"discount\": 0\r\n    }\r\n  ]\r\n}";
            }
            if (comboBox2.Text == "Orders" && comboBox3.Text == "Post")
            {
                command = tb_View.Text = "{\r\n  \"userId\": 0,\r\n  \"items\": [\r\n    {\r\n      \"productId\": 0,\r\n      \"count\": 0,\r\n      \"discount\": 0\r\n    }\r\n  ]\r\n}";
            }
        }
    }
}
